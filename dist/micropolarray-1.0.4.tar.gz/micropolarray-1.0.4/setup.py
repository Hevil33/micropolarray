from distutils.core import setup

setup(
    url="https://github.com/Hevil33/micropolarray_master",
    author="Hervé Haudemand",
    author_email="herve.haudemand@inaf.it",
    packages=[
        "micropolarray",
        "micropolarray.processing",
        "micropolarray.tests",
    ],  # name of the uppermost package directory
    package_dir={"micropolarray": "./build/micropolarray"},
)
